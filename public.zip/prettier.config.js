const config = {
  bracketSpacing: true,
  semi: false,
  singleQuote: true,
  trailingComma: "es5",
  printWidth: 10000,
  useTabs: true,
  tabWidth:2,
  arrowParens:"always",
};
export default config;