const products = [
	{
		product: 'ASOS Ridley High Waist',
		price: 79.49,
		orders: 82,
		quantity: '8,540',
		seller: 'Adidas',
	},
	{
		product: 'Marco Lightweight Shirt',
		price: 12.5,
		orders: 58,
		quantity: '6,320',
		seller: 'Puma',
	},
	{
		product: 'Half Sleeve Shirt',
		price: 9.99,
		orders: 254,
		quantity: '10,258',
		seller: 'Nike',
	},
	{
		product: 'Lightweight Jacket',
		price: 69.99,
		orders: 560,
		quantity: '1,020',
		seller: 'Puma',
	},
	{
		product: 'Marco Sport Shoes',
		price: 119.99,
		orders: 75,
		quantity: '357',
		seller: 'Adidas',
	},
	{
		product: "Custom Women's T-shirts",
		price: 45.0,
		orders: 85,
		quantity: '135',
		seller: 'Branded',
	},
]

export { products }
