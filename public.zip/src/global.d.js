declare module 'google-maps-react'
declare module 'react-color'
