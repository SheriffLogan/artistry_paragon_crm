// components

import { PageBreadcrumb } from '../../components'

const StarterPages = () => {
	return (
		<>
			<PageBreadcrumb title="Starter Page" subName="Pages" />
		</>
	)
}

export default StarterPages
